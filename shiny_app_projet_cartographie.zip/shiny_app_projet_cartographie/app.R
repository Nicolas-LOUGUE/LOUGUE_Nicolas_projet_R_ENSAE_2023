# Charger les packages
library(shiny)
library(tmap)
library(tmaptools)
library(rnaturalearth)
library(tidyverse)
library(sf)

# Charger les données depuis le fichier CSV
donnees <- read.csv("ACLED-Western_Africa.csv")

# Création de l'interface utilisateur
ui <- fluidPage(
  # Titre de l'application
  titlePanel("Carte des évènements d'ordre politiques de l'Afrique de l'Ouest"),
  
  # Sidebar avec les options de filtrage
  sidebarLayout(
    sidebarPanel(
      selectizeInput(
        inputId = "pays",
        label = "Sélectionnez un ou plusieurs pays",
        choices = unique(donnees$pays),
        selected = "Burkina Faso",
        multiple = TRUE,
        options = list(`actions-box` = TRUE, `live-search` = TRUE)
      ),
      selectizeInput(
        inputId = "type_evenement",
        label = "Sélectionnez un ou plusieurs types d'événements",
        choices = unique(donnees$type),
        selected = "Protests",
        multiple = TRUE,
        options = list(`actions-box` = TRUE, `live-search` = TRUE)
      ),
      selectizeInput(
        inputId = "annee",
        label = "Sélectionnez une ou plusieurs années",
        choices = unique(donnees$annee),
        selected = "2015",
        multiple = TRUE,
        options = list(`actions-box` = TRUE, `live-search` = TRUE)
      )
    ),
    
    # Affichage de la carte tmap
    mainPanel(
      tmapOutput(outputId = "carte",
                 width = "100%",
                 height = "500px")
    )
  )
)

# Logique du serveur
server <- function(input, output, session) {
  filtered_data <- reactive({
    donnees %>%
      filter(pays %in% input$pays &type %in% input$type_evenement & annee %in% input$annee)
  })
  
  output$carte <- renderTmap({
    donnees_filtrage <- filtered_data() 
    donnees_filtrage <-donnees_filtrage [, c("id","date","annee","type","pays","longitude", "latitude")]
    
    # Création de la carte tmap
    carte_tmap <- tm_shape(ne_states(country = input$pays, returnclass = "sf")) +
      tm_borders(lwd = 0.5) +
      tm_fill(col = "lightblue", alpha = 0.6) +
      tm_shape(st_as_sf(na.omit(donnees_filtrage), coords=c("longitude","latitude"))) +
      tm_bubbles(size = 0.01, col = "red", alpha = 0.7)
    
    tmap::tmap_mode("view")  # Mode interactif de tmap pour la carte
    
    carte_tmap
  })
}

# Lancement de l'application Shiny
shinyApp(ui = ui, server = server)
